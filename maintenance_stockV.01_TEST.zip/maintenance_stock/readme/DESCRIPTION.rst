This module extends the functionality of Odoo Maintenance module by allowing
link stock consumptions to maintenance requests.
