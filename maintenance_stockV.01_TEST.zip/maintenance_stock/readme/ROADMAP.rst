* Product standard list. Enable defining product standard lists (at least, 
  product and quantity per line), and link them with equipments. Then, every 
  maintenance request could select one of them and automatically fill the 
  product and quantity list.